from torchvision.models import resnet50
from torch import nn

class BaseResnet50(nn.Module):
    def __init__(self,pretrained = True):
        super(BaseResnet50,self).__init__()
        base_net = resnet50(pretrained=pretrained)
        self.conv1 = base_net.conv1
        self.bn1 = base_net.bn1
        self.relu = base_net.relu
        self.maxpool = base_net.maxpool
        
        self.layer1 = base_net.layer1
        self.layer2 = base_net.layer2
        self.layer3 = base_net.layer3
        self.layer4 = base_net.layer4
        
        self.avgpool = base_net.avgpool
        
        self.dropout = nn.Dropout(0.5)
        
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)

        conv5_b = self.layer4[:2](x)
        x = self.layer4[2](conv5_b)

        fm = x
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        embeeding = x

        return fm, embeeding, conv5_b